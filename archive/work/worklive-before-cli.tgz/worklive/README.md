# Worklive

A local Tauri desktop prototype where agents have desks, characters, and real browser screens in a 3D office.

## Try it

Open the accompanying **Worklive.app**. This build is for the current Apple Silicon Mac and uses its installed Node.js and Google Chrome (Chromium and Brave are fallbacks).

1. Select **Run browser practice** for Ada.
2. Click the little monitor, or **Open browser**, to watch the same Chromium session at full size.
3. Select **Take control**. The current agent action finishes and queued actions are cancelled before control is acknowledged.
4. Click, type, paste, or scroll in the browser. The address bar accepts real http/https pages while you have control.
5. Select **Return control** to resume the practice task, or **Stop task** to stop it.
6. **View saved notes** opens the verified output after the practice task completes.
7. **Coffee break** invites free agents to the community table. Idle agents also take coffee, stretch, and water plants on their own. **Pause movement** freezes office life.
8. **New agent** adds a character, desk, and separate browser context. Names, roles, personalities, and task briefs are saved locally.

The practice task uses actual browser navigation, clicks, text entry, and a saved result. It is a fixed sequence on a local practice website. No language model is connected and general task briefs are not executed yet. Office conversations are also scripted ambient animation, marked “Just for fun”; they are not model reasoning or work delegation.

## What is implemented

- Tauri/Rust desktop shell and local agent persistence.
- Three.js office with working characters, coffee mugs, sipping gestures, stretches, watering cans, and speech bubbles.
- Routes around furniture, personal space, and reserved activity spots for up to six agents.
- A community coffee table and paired, playful conversations. Browser work interrupts breaks and agents walk back to their own desks.
- Separate office-life and browser-activity displays; decorative chatter never runs an agent task.
- A separate Playwright/Chromium worker, with one isolated browser context per agent.
- Real browser frames shared between the desk texture and expanded view.
- Throttled previews, faster foreground capture, and stale-frame timestamps.
- Serialized input, explicit ownership handoff, and cancellation of queued automation.
- Mouse clicks, keyboard input, paste, wheel scrolling, navigation, history, and reload.
- Scripted research task with a page-level success check and a local text output.

## Current boundaries

Browser contexts survive switching views but are fresh when Worklive restarts. They do not use your personal Chrome profile. The first version has one tab per agent; popup tabs are closed. Browser login persistence, downloads, drag gestures, general agent tools, model connections, model-driven inter-agent collaboration, and terminal/document execution are future work. Authentication flows that require popups or a headed browser may not work in this prototype.

The packaged application includes the browser worker and its library. It currently relies on the installed Node.js and browser executables, so it is a local prototype rather than a self-contained public release. Build and run on this Mac; distribution signing and notarization are not configured.

Agent details and task outputs are stored under the standard application-data directory for `com.worklive.prototype`. Browser pages run outside the Tauri UI. They receive no Tauri commands or filesystem bridge. The worker accepts structured actions over private standard input/output; the practice web server listens only on loopback.

## Development

Requirements: Node.js, Rust, Xcode command line tools, Google Chrome/Chromium/Brave.

```sh
npm run setup
npm run dev
npm run check
npm run build -- --debug
```

The source is organized as:

- `src/`: office scene, standalone movement/routine simulation, desktop UI, and frame/input presentation.
- `tests/`: simulation checks for six-agent spacing, furniture avoidance, arrivals, conversations, low frame rates, and work interruptions.
- `src-tauri/`: native shell, worker lifecycle, private message transport, saved agents.
- `worker/`: isolated Chromium sessions, actual page actions, practice site, control handoff tests.

## Next integration

Adapt Workspace-OS's browser action vocabulary, agent activity feed, and output review concepts behind this browser service. Bring TerminalOS's conversation and captured-source workflow into each workstation. Keep the visual office independent of the agent runtime so a future model adapter can emit the same work and browser events.

The source projects were inspected as references; neither existing application was changed.
