import "./style.css";
import { invoke, Channel } from "@tauri-apps/api/core";
import { createIcons, icons } from "lucide";
import { createOffice } from "./office";
import type { Agent, BrowserEvent, BrowserState } from "./types";

document.querySelector("#app")!.innerHTML = `
<header class="app-header"><div class="brand"><span class="brand-mark">w</span><span>Worklive<small>A little space for big ideas.</small></span></div><div class="header-actions"><span class="connection" id="connection">Starting browser service…</span><button class="primary" id="add-agent"><i data-lucide="plus"></i> New agent</button></div></header>
<main id="office-view" class="office-layout"><section class="office-workspace"><div class="scene-heading"><div><span class="eyebrow">YOUR TEAM, TOGETHER</span><h1>The studio.</h1><p id="team-summary">One desk. Room to grow.</p></div><div class="scene-controls"><button id="rotate-left" class="icon-button" aria-label="Rotate office left"><i data-lucide="rotate-ccw"></i></button><button id="rotate-right" class="icon-button" aria-label="Rotate office right"><i data-lucide="rotate-cw"></i></button><button id="zoom-in" class="icon-button" aria-label="Zoom in"><i data-lucide="plus"></i></button><button id="zoom-out" class="icon-button" aria-label="Zoom out"><i data-lucide="minus"></i></button></div></div><div id="office-scene"></div><div class="scene-caption"><span><i data-lucide="scan"></i>Click a monitor to open the real browser.</span><button id="motion" class="quiet">Pause movement</button></div><section class="office-life-panel" aria-label="Office life"><div><span class="eyebrow">OFFICE LIFE <span class="playful-badge">JUST FOR FUN</span></span><p id="office-moment" role="status">Coffee, small talk, and a little room to breathe.</p></div><button id="coffee-break" class="secondary" title="Invite free agents to the community table"><i data-lucide="coffee"></i>Coffee break</button></section><section class="activity-panel"><div class="panel-heading"><h2>Around the office</h2><span>REAL BROWSER ACTIVITY</span></div><div id="activity" aria-live="polite"><div class="activity-item">Your studio is opening.</div></div></section></section>
<aside class="inspector"><div class="profile"><span id="agent-avatar" class="avatar"><i data-lucide="bot"></i></span><div><h2 id="agent-name">Ada</h2><span id="agent-status">Opening browser</span></div></div><button id="open-screen" class="primary wide"><i data-lucide="monitor-up"></i>Open browser</button><div class="inspector-fields"><label>Name<input id="edit-name" maxlength="40"></label><label>Role<select id="edit-role"><option>Researcher</option><option>Designer</option><option>Developer</option><option>Coordinator</option><option>Writer</option><option>Generalist</option></select></label><label>Personality<textarea id="edit-personality" maxlength="500" rows="3"></textarea></label><label>Task brief<textarea id="edit-task" maxlength="1000" rows="3"></textarea></label></div><div class="practice-block"><span class="eyebrow">FIRST WORKING EXPERIMENT</span><h3>Read. Write. Save.</h3><p>A scripted agent reads a real practice webpage, writes notes, and saves the result.</p><button id="run-demo" class="secondary wide"><i data-lucide="play"></i><span>Run browser practice</span></button><button id="view-notes" class="quiet wide"><i data-lucide="file-text"></i>View saved notes</button></div><div class="inspector-note">Live Chromium browser · isolated session<br>Language-model agents are not connected yet.</div></aside></main>
<main id="browser-view" class="browser-layout" hidden><div class="browser-heading"><div class="browser-heading-left"><button id="back-office" class="secondary"><i data-lucide="arrow-left"></i>Office</button><div><h1 id="computer-title">Ada’s computer</h1><p id="computer-subtitle">Watching the same session as the desk monitor.</p></div></div><div class="browser-heading-right"><button id="stop-demo" class="secondary"><i data-lucide="square"></i>Stop task</button><button id="take-control" class="primary"><i data-lucide="mouse-pointer-2"></i><span>Take control</span></button></div></div><div class="browser-columns"><section class="computer"><div class="browser-toolbar"><button id="browser-back" class="icon-button" aria-label="Browser back"><i data-lucide="arrow-left"></i></button><button id="browser-forward" class="icon-button" aria-label="Browser forward"><i data-lucide="arrow-right"></i></button><button id="browser-reload" class="icon-button" aria-label="Reload page"><i data-lucide="rotate-cw"></i></button><form id="address-form"><i data-lucide="globe"></i><input id="address" aria-label="Browser address" placeholder="https://example.com" autocomplete="off" spellcheck="false"><button type="submit" class="address-go" aria-label="Open address">↵</button></form><button id="browser-home" class="icon-button" aria-label="Open practice page"><i data-lucide="house"></i></button></div><div id="browser-surface" class="browser-surface" tabindex="0" role="application" aria-label="Live browser. Take control to click, type, paste, and scroll."><img id="browser-frame" alt="Live agent browser" draggable="false"><span id="browser-cursor" class="browser-cursor" hidden></span><div id="browser-placeholder">Opening the browser session…</div></div><div class="computer-footer"><span id="control-hint">Watching · Take control to interact</span><span id="frame-status">Waiting for first frame</span></div></section><aside class="browser-activity"><div class="ownership"><span class="status-dot"></span><span id="owner-status">Agent in control</span></div><span class="eyebrow">CURRENT TASK</span><p id="focused-task"></p><ol class="task-steps"><li data-step="1"><span>1</span>Open research library</li><li data-step="2"><span>2</span>Read a reference</li><li data-step="3"><span>3</span>Open the notes</li><li data-step="4"><span>4</span>Write key ideas</li><li data-step="5"><span>5</span>Save and verify</li></ol><p id="task-message" aria-live="polite"></p><button id="focus-run" class="secondary wide"><i data-lucide="play"></i>Run browser practice</button><button id="focus-notes" class="quiet wide"><i data-lucide="file-text"></i>View saved notes</button><p class="fine-print">The browser is real. The practice task uses a fixed sequence of actions on a local webpage.</p></aside></div><nav id="computer-switcher" aria-label="Agent computers"></nav></main>
<footer class="app-footer"><span id="footer-context">Office / Creative studio</span><span>Tauri + Rust · A living office · 0.2</span></footer><div id="toast" role="alert" hidden></div>
<dialog id="new-dialog"><form id="new-form"><div class="dialog-heading"><h2>A new face in the studio.</h2><button type="button" id="cancel-new" class="icon-button" aria-label="Close new agent dialog"><i data-lucide="x"></i></button></div><label>Name<input name="name" required maxlength="40" placeholder="e.g. Milo"></label><label>Role<select name="role"><option>Researcher</option><option>Designer</option><option>Developer</option><option>Coordinator</option><option>Writer</option><option>Generalist</option></select></label><label>Personality<textarea name="personality" rows="3" maxlength="500" placeholder="Curious, thoughtful, and direct."></textarea></label><p class="fine-print">A desk and a separate browser session will be created.</p><button class="primary wide" type="submit">Create agent</button></form></dialog>
<dialog id="notes-dialog"><div class="dialog-heading"><h2>Saved research notes</h2><button id="close-notes" class="icon-button" aria-label="Close saved notes"><i data-lucide="x"></i></button></div><pre id="notes-text"></pre><p id="notes-path" class="fine-print"></p></dialog>`;
createIcons({ icons });
const $ = <T extends HTMLElement = HTMLElement>(selector: string) =>
  document.querySelector<T>(selector)!;
let agents: Agent[] = [],
  selected = "",
  focused: string | null = null,
  ready = false,
  pendingControl = false,
  saveTimer: ReturnType<typeof setTimeout>,
  toastTimer: ReturnType<typeof setTimeout>;
const browserStates = new Map<string, BrowserState>(),
  frames = new Map<
    string,
    {
      url: string;
      seq: number;
      at: number;
      cursor?: { x: number; y: number } | null;
    }
  >(),
  activity: { name: string; message: string }[] = [];
const office = createOffice(
  $("#office-scene"),
  selectAgent,
  openComputer,
  (moment) => {
    $("#office-moment").textContent = moment.speaker
      ? `${moment.speaker}: “${moment.text}”`
      : moment.text;
  },
);
$("#motion").textContent = office.isMoving()
  ? "Pause movement"
  : "Resume movement";
$("#coffee-break").onclick = () => {
  if (!office.isMoving()) {
    $("#office-moment").textContent =
      "Resume movement to enjoy a coffee break.";
    return;
  }
  if (!office.coffeeBreak())
    $("#office-moment").textContent =
      "Everyone is busy. Coffee can wait until they are free.";
};
function showError(error: unknown) {
  const toast = $("#toast");
  toast.textContent = String(error);
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toast.hidden = true), 6500);
}
async function command(
  action: string,
  agentId = focused || selected,
  extra: Record<string, unknown> = {},
): Promise<any> {
  if (!ready) throw new Error("The browser service is still starting.");
  return invoke("browser_command", { command: { action, agentId, ...extra } });
}
function run(action: () => Promise<unknown>) {
  void action().catch(showError);
}
function current() {
  return agents.find((a) => a.id === (focused || selected))!;
}
function record(id: string, message: string) {
  const name = agents.find((a) => a.id === id)?.name || "Worklive";
  activity.unshift({ name, message });
  activity.splice(4);
  const panel = $("#activity");
  panel.replaceChildren();
  for (const item of activity) {
    const row = document.createElement("div");
    row.className = "activity-item";
    const dot = document.createElement("span");
    dot.className = "activity-dot";
    const text = document.createElement("span");
    const strong = document.createElement("strong");
    strong.textContent = item.name;
    text.append(strong, document.createTextNode(" · " + item.message));
    row.append(dot, text);
    panel.append(row);
  }
}
function statusText(s?: BrowserState) {
  if (!s) return "Opening browser";
  if (s.owner === "user") return "You have control";
  return {
    idle: "Available",
    working: "Working",
    paused: "Paused",
    complete: "Task complete",
    error: "Needs attention",
    loading: "Opening page",
  }[s.status];
}
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    void invoke("save_agents", { agents }).catch(showError);
  }, 350);
}
function refresh() {
  const a = agents.find((a) => a.id === selected);
  if (!a) return;
  const state = browserStates.get(a.id);
  $("#agent-name").textContent = a.name;
  $("#agent-status").textContent = statusText(state);
  $("#agent-avatar").style.background = a.color;
  for (const field of ["name", "role", "personality", "task"] as const) {
    const input = $<HTMLInputElement | HTMLTextAreaElement>("#edit-" + field);
    if (document.activeElement !== input) input.value = a[field];
  }
  office.setAgents(agents);
  office.select(a.id);
  const working = [...browserStates.values()].filter(
    (s) => s.status === "working",
  ).length;
  $("#team-summary").textContent =
    `${agents.length} ${agents.length === 1 ? "agent" : "agents"} · ${working} working · room to grow`;
  $<HTMLButtonElement>("#add-agent").disabled = agents.length >= 6;
  $<HTMLButtonElement>("#run-demo").disabled =
    !state ||
    state.owner === "user" ||
    state.status === "working" ||
    state.status === "loading";
  $("#run-demo span").textContent =
    state?.status === "working"
      ? "Practice task running"
      : "Run browser practice";
  $<HTMLButtonElement>("#view-notes").disabled = !state?.hasRun;
  refreshFocus();
}
function selectAgent(id: string) {
  selected = id;
  office.select(id);
  refresh();
}
async function openComputer(id: string) {
  selected = id;
  focused = id;
  $("#office-view").hidden = true;
  $("#browser-view").hidden = false;
  $("#footer-context").textContent = "Computer / Live browser";
  refresh();
  paintFocusedFrame();
  buildSwitcher();
  try {
    await command("ensure", id);
    await command("focus", id);
  } catch (e) {
    showError(e);
  }
  refreshFocus();
}
function closeComputer() {
  focused = null;
  $("#browser-view").hidden = true;
  $("#office-view").hidden = false;
  $("#footer-context").textContent = "Office / Creative studio";
  run(() => command("focus", ""));
  refresh();
}
function buildSwitcher() {
  const row = $("#computer-switcher");
  row.replaceChildren();
  for (const a of agents) {
    const b = document.createElement("button");
    b.className = "secondary";
    b.textContent = a.name;
    b.setAttribute("aria-pressed", String(a.id === focused));
    b.onclick = () => void openComputer(a.id);
    row.append(b);
  }
}
function refreshFocus() {
  if (!focused) return;
  const a = current(),
    s = browserStates.get(focused);
  $("#computer-title").textContent = a.name + "’s computer";
  $("#computer-subtitle").textContent =
    s?.owner === "user"
      ? "You have control · agent input paused"
      : "Watching the same session as the desk monitor";
  $("#focused-task").textContent = a.task || "No task brief assigned.";
  const user = s?.owner === "user";
  $("#owner-status").textContent = user
    ? "You have control"
    : "Agent in control";
  $("#take-control span").textContent = pendingControl
    ? "Switching control…"
    : user
      ? "Return control"
      : "Take control";
  $<HTMLButtonElement>("#take-control").disabled = !s || pendingControl;
  $("#take-control").classList.toggle("user-control", user);
  $("#browser-surface").classList.toggle("is-controlled", user);
  $("#control-hint").textContent = user
    ? "Your mouse and keyboard control this browser"
    : "Watching · Take control to interact";
  const address = $<HTMLInputElement>("#address");
  if (document.activeElement !== address) address.value = s?.url || "";
  address.disabled = !user;
  for (const id of [
    "browser-back",
    "browser-forward",
    "browser-reload",
    "browser-home",
  ])
    $<HTMLButtonElement>("#" + id).disabled = !user;
  $("#task-message").textContent = s?.message || "Opening browser…";
  $("#stop-demo").hidden = s?.status !== "working" && s?.status !== "paused";
  $<HTMLButtonElement>("#focus-run").disabled =
    !s || user || s.status === "working" || s.status === "loading";
  $<HTMLButtonElement>("#focus-notes").disabled = !s?.hasRun;
  document.querySelectorAll<HTMLElement>("[data-step]").forEach((el) => {
    const step = Number(el.dataset.step);
    el.classList.toggle("done", !!s && s.step >= step);
    el.classList.toggle(
      "active",
      !!s && s.status === "working" && s.step === step - 1,
    );
  });
}
function paintFocusedFrame() {
  if (!focused) return;
  const frame = frames.get(focused);
  const img = $<HTMLImageElement>("#browser-frame");
  if (frame) {
    img.src = frame.url;
    img.hidden = false;
    $("#browser-placeholder").hidden = true;
    const cursor = $("#browser-cursor");
    cursor.hidden =
      !frame.cursor || browserStates.get(focused)?.owner === "user";
    if (frame.cursor) {
      cursor.style.left = (frame.cursor.x / 1024) * 100 + "%";
      cursor.style.top = (frame.cursor.y / 640) * 100 + "%";
    }
  } else {
    img.hidden = true;
    $("#browser-placeholder").hidden = false;
    $("#browser-cursor").hidden = true;
  }
}
function receive(e: BrowserEvent) {
  if (e.type === "state" && e.state) {
    browserStates.set(e.state.agentId, e.state);
    office.state(e.state);
    refresh();
  } else if (e.type === "frame" && e.agentId && e.image) {
    const id = e.agentId,
      seq = e.seq || 0;
    if (seq <= (frames.get(id)?.seq || 0)) return;
    const frame = {
      url: "data:image/jpeg;base64," + e.image,
      seq,
      at: Date.now(),
      cursor: e.cursor,
    };
    frames.set(id, frame);
    const image = new Image();
    image.onload = () => {
      if (frames.get(id)?.seq === seq) office.frame(id, image);
    };
    image.src = frame.url;
    if (focused === id) paintFocusedFrame();
  } else if (e.type === "activity" && e.agentId && e.message)
    record(e.agentId, e.message);
  else if (e.type === "offline") {
    ready = false;
    $("#connection").textContent = "Browser disconnected";
    $("#connection").classList.remove("connected");
    showError(e.message);
  }
}
for (const field of ["name", "role", "personality", "task"] as const)
  $<HTMLInputElement>("#edit-" + field).addEventListener("input", (event) => {
    const a = agents.find((a) => a.id === selected)!;
    a[field] = (event.target as HTMLInputElement).value;
    office.setAgents(agents);
    persist();
    refresh();
  });
$("#open-screen").onclick = () => void openComputer(selected);
$("#back-office").onclick = closeComputer;
$("#rotate-left").onclick = () => office.rotate(-10);
$("#rotate-right").onclick = () => office.rotate(10);
$("#zoom-in").onclick = () => office.zoom(0.1);
$("#zoom-out").onclick = () => office.zoom(-0.1);
$("#motion").onclick = () => {
  $("#motion").textContent = office.motion()
    ? "Pause movement"
    : "Resume movement";
};
const startDemo = async () => {
  const id = focused || selected;
  await command("ensure", id);
  await command("runDemo", id);
};
$("#run-demo").onclick = () => run(startDemo);
$("#focus-run").onclick = () => run(startDemo);
$("#stop-demo").onclick = () => run(() => command("stopDemo"));
$("#take-control").onclick = () =>
  run(async () => {
    pendingControl = true;
    refreshFocus();
    try {
      const user = browserStates.get(focused!)?.owner === "user";
      await command(user ? "returnControl" : "takeControl");
      if (!user) $("#browser-surface").focus({ preventScroll: true });
    } finally {
      pendingControl = false;
      refreshFocus();
    }
  });
$("#address-form").onsubmit = (e) => {
  e.preventDefault();
  let url = $<HTMLInputElement>("#address").value.trim();
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  run(() => command("navigate", focused!, { url }));
};
for (const [id, action] of [
  ["browser-back", "back"],
  ["browser-forward", "forward"],
  ["browser-reload", "reload"],
  ["browser-home", "home"],
])
  $("#" + id).onclick = () => run(() => command(action));
const surface = $("#browser-surface");
function isUser() {
  return (
    !!focused && browserStates.get(focused)?.owner === "user" && !pendingControl
  );
}
surface.addEventListener("click", (e) => {
  if (!isUser()) {
    showError("Choose “Take control” to interact with this browser.");
    return;
  }
  surface.focus({ preventScroll: true });
  const r = $("#browser-frame").getBoundingClientRect();
  run(() =>
    command("click", focused!, {
      x: Math.max(0, Math.min(1024, ((e.clientX - r.left) / r.width) * 1024)),
      y: Math.max(0, Math.min(640, ((e.clientY - r.top) / r.height) * 640)),
      count: e.detail > 1 ? 2 : 1,
    }),
  );
});
let wheelAt = 0;
surface.addEventListener(
  "wheel",
  (e) => {
    if (!isUser()) return;
    e.preventDefault();
    if (Date.now() - wheelAt < 35) return;
    wheelAt = Date.now();
    run(() => command("scroll", focused!, { dx: e.deltaX, dy: e.deltaY }));
  },
  { passive: false },
);
surface.addEventListener("keydown", (e) => {
  if (!isUser()) return;
  if (e.key === "Escape") {
    surface.blur();
    return;
  }
  if (["Shift", "Control", "Meta", "Alt"].includes(e.key)) return;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") return;
  e.preventDefault();
  if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
    run(() => command("text", focused!, { text: e.key }));
  } else {
    let key = e.key;
    if (e.metaKey) key = "Meta+" + key;
    else if (e.ctrlKey) key = "Control+" + key;
    if (e.altKey) key = "Alt+" + key;
    if (e.shiftKey && e.key !== "Shift") key = "Shift+" + key;
    run(() => command("key", focused!, { key }));
  }
});
surface.addEventListener("paste", (e) => {
  if (!isUser()) return;
  e.preventDefault();
  const text = e.clipboardData?.getData("text/plain");
  if (text) run(() => command("text", focused!, { text }));
});
$("#add-agent").onclick = () => {
  $<HTMLDialogElement>("#new-dialog").showModal();
  $<HTMLInputElement>("#new-form input").focus();
};
$("#cancel-new").onclick = () => $<HTMLDialogElement>("#new-dialog").close();
$("#new-form").onsubmit = (e) => {
  e.preventDefault();
  if (agents.length >= 6) return;
  const form = $<HTMLFormElement>("#new-form"),
    values = new FormData(form),
    name = String(values.get("name") || "").trim();
  if (!name) return;
  const colors = [
    "#aec49a",
    "#d6aa87",
    "#a8bfd0",
    "#bba6c9",
    "#cbbc84",
    "#93beb1",
  ];
  const a: Agent = {
    id: "agent-" + crypto.randomUUID(),
    name,
    role: String(values.get("role")),
    personality: String(
      values.get("personality") ||
        "Thoughtful, resourceful, and ready to help.",
    ),
    task: "",
    color: colors[agents.length],
  };
  agents.push(a);
  selected = a.id;
  office.setAgents(agents);
  refresh();
  persist();
  form.reset();
  $<HTMLDialogElement>("#new-dialog").close();
  run(() => command("ensure", a.id));
};
async function notes() {
  const result = await command("notes");
  $("#notes-text").textContent =
    result.text ||
    "No saved output yet. Complete the browser practice task first.";
  $("#notes-path").textContent = result.text
    ? "Saved locally: " + result.path
    : "";
  $<HTMLDialogElement>("#notes-dialog").showModal();
}
$("#view-notes").onclick = () => run(notes);
$("#focus-notes").onclick = () => run(notes);
$("#close-notes").onclick = () => $<HTMLDialogElement>("#notes-dialog").close();
setInterval(() => {
  if (!focused) return;
  const f = frames.get(focused);
  $("#frame-status").textContent = f
    ? Date.now() - f.at < 3000
      ? "Live · Chromium · 1024 × 640"
      : "Last frame " + Math.round((Date.now() - f.at) / 1000) + "s ago"
    : "Waiting for first frame";
}, 1000);
async function start() {
  try {
    const saved = await invoke<Agent[]>("load_agents");
    agents = saved.length
      ? saved
      : [
          {
            id: "ada",
            name: "Ada",
            role: "Researcher",
            personality:
              "Curious, methodical, and quietly opinionated. Always brings sources.",
            task: "Read a reference about thoughtful workspaces and save the key ideas.",
            color: "#aec49a",
          },
        ];
    selected = agents[0].id;
    office.setAgents(agents);
    refresh();
    const channel = new Channel<BrowserEvent>();
    channel.onmessage = receive;
    await invoke("start_browser", { onEvent: channel });
    ready = true;
    await command("hello");
    $("#connection").textContent = "Browser service connected";
    $("#connection").classList.add("connected");
    for (const a of agents) await command("ensure", a.id);
    persist();
  } catch (e) {
    $("#connection").textContent = "Setup needs attention";
    showError(e);
  }
}
void start();
