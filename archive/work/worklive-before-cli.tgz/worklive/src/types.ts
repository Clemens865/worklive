export interface Agent {
  id: string;
  name: string;
  role: string;
  personality: string;
  task: string;
  color: string;
}
export interface BrowserState {
  agentId: string;
  owner: "agent" | "user";
  status: "idle" | "working" | "paused" | "complete" | "error" | "loading";
  url: string;
  title: string;
  step: number;
  message: string;
  hasRun: boolean;
}
export interface BrowserEvent {
  type: string;
  agentId?: string;
  state?: BrowserState;
  image?: string;
  seq?: number;
  message?: string;
  width?: number;
  height?: number;
  cursor?: { x: number; y: number } | null;
}
