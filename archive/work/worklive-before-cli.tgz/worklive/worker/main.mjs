import { chromium } from "playwright-core";
import { createServer } from "node:http";
import { createInterface } from "node:readline";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { ControlLane } from "./control.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const data = process.argv[2];
const agents = new Map();
let browser,
  browserStarting,
  focused = null,
  closing = false,
  backpressure = false;
function emit(value) {
  if (value.type === "frame" && backpressure) return;
  const ok = process.stdout.write(JSON.stringify(value) + "\n");
  if (!ok) {
    backpressure = true;
    process.stdout.once("drain", () => {
      backpressure = false;
    });
  }
}
const practice = await readFile(join(root, "practice.html"));
const server = createServer((req, res) => {
  if (req.url !== "/" && req.url !== "/practice") {
    res.writeHead(404);
    res.end();
    return;
  }
  res.writeHead(200, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(practice);
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const practiceURL = "http://127.0.0.1:" + server.address().port + "/practice";
function idOf(id) {
  if (typeof id !== "string" || !/^[a-zA-Z0-9_-]{1,64}$/.test(id))
    throw new Error("Invalid agent identity");
  return id;
}
function validUrl(value) {
  const u = new URL(value);
  if (!["http:", "https:"].includes(u.protocol) || u.username || u.password)
    throw new Error(
      "Use an http or https address without embedded credentials.",
    );
  return u.href;
}
function state(a) {
  return {
    agentId: a.id,
    owner: a.lane.owner,
    status: a.status,
    url: a.page?.url() || "",
    title: a.title || "",
    step: a.step,
    message: a.message,
    hasRun: a.hasRun,
  };
}
function publish(a) {
  emit({ type: "state", agentId: a.id, state: state(a) });
}
function activity(a, message) {
  a.message = message;
  emit({ type: "activity", agentId: a.id, message });
  publish(a);
}
async function startBrowser() {
  if (browser) return browser;
  if (browserStarting) return browserStarting;
  browserStarting = (async () => {
    const executable = [
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Chromium.app/Contents/MacOS/Chromium",
      "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    ].find(existsSync);
    if (!executable)
      throw new Error(
        "Install Google Chrome, Chromium, or Brave to run Worklive’s browser.",
      );
    browser = await chromium.launch({
      executablePath: executable,
      headless: true,
      args: [
        "--disable-background-timer-throttling",
        "--disable-renderer-backgrounding",
      ],
    });
    browser.on("disconnected", () => {
      if (!closing) {
        for (const a of agents.values()) {
          a.status = "error";
          a.message = "The browser stopped. Relaunch Worklive to reconnect.";
          publish(a);
        }
      }
    });
    return browser;
  })();
  try {
    return await browserStarting;
  } finally {
    browserStarting = null;
  }
}
async function ensure(id) {
  id = idOf(id);
  if (agents.has(id)) {
    const existing = agents.get(id);
    if (existing.ready) await existing.ready;
    return existing;
  }
  if (agents.size >= 6) throw new Error("This prototype supports six agents.");
  const a = {
    id,
    lane: new ControlLane(),
    status: "loading",
    title: "Starting browser",
    step: 0,
    message: "Opening a browser session",
    hasRun: false,
    runActive: false,
    queue: null,
    capturing: false,
    seq: 0,
    nextCapture: 0,
    cursor: null,
  };
  agents.set(id, a);
  publish(a);
  a.ready = (async () => {
    try {
      a.hasRun = !!(
        data && existsSync(join(data, "outputs", a.id + "-research-notes.txt"))
      );
      const b = await startBrowser();
      a.context = await b.newContext({
        viewport: { width: 1024, height: 640 },
        deviceScaleFactor: 1,
        acceptDownloads: false,
        permissions: [],
      });
      a.page = await a.context.newPage();
      a.page.setDefaultTimeout(5000);
      a.page.setDefaultNavigationTimeout(20000);
      a.context.on("page", (p) => {
        if (p !== a.page) void p.close();
      });
      a.page.on("dialog", (d) => void d.dismiss());
      a.page.on("framenavigated", (frame) => {
        if (frame === a.page.mainFrame()) {
          publish(a);
        }
      });
      a.page.on("load", () => {
        void a.page
          .title()
          .then((title) => {
            a.title = title;
            publish(a);
          })
          .catch(() => {});
      });
      await a.page.goto(practiceURL, { waitUntil: "domcontentloaded" });
      a.title = await a.page.title();
      a.status = "idle";
      activity(a, "Browser ready. Start the practice task or take control.");
      return a;
    } catch (e) {
      a.status = "error";
      activity(a, e.message);
      agents.delete(id);
      await a.context?.close().catch(() => {});
      throw e;
    }
  })();
  await a.ready;
  return a;
}
async function capture(a) {
  if (
    !a.page ||
    a.capturing ||
    closing ||
    backpressure ||
    Date.now() < a.nextCapture
  )
    return;
  a.capturing = true;
  a.nextCapture = Date.now() + (focused === a.id ? 180 : 650);
  try {
    const image = await a.page.screenshot({
      type: "jpeg",
      quality: focused === a.id ? 80 : 65,
      timeout: 5000,
    });
    emit({
      type: "frame",
      agentId: a.id,
      seq: ++a.seq,
      image: image.toString("base64"),
      width: 1024,
      height: 640,
      cursor: a.cursor,
    });
  } catch {
  } finally {
    a.capturing = false;
  }
}
const captureTimer = setInterval(() => {
  for (const a of agents.values()) void capture(a);
}, 90);
async function pointAt(a, selector) {
  const rect = await a.page.locator(selector).boundingBox();
  if (rect) {
    a.cursor = { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    await a.page.mouse.move(a.cursor.x, a.cursor.y);
  }
}
const steps = [
  async (a) => {
    activity(a, "Opening the practice research library");
    await a.page.goto(practiceURL, { waitUntil: "domcontentloaded" });
  },
  async (a) => {
    activity(a, "Reading “The calm studio”");
    await pointAt(a, "#open-source");
    await a.page.locator("#open-source").click();
  },
  async (a) => {
    activity(a, "Opening the research notes");
    await pointAt(a, "#make-notes");
    await a.page.locator("#make-notes").click();
  },
  async (a) => {
    activity(a, "Writing three ideas into the page");
    await pointAt(a, "#note");
    await a.page
      .locator("#note")
      .fill(
        "Worklive research notes\n\n• Give every agent a desk and a persistent workspace.\n• Mirror the real browser on the desk monitor.\n• Pause agent input while a person takes control.",
      );
  },
  async (a) => {
    activity(a, "Saving notes and checking the result");
    await pointAt(a, "#save-notes");
    await a.page.locator("#save-notes").click();
    await a.page.locator("#saved").waitFor({ state: "visible" });
    const note = await a.page.locator("#note").inputValue();
    if (!note.trim())
      throw new Error("The page did not contain the expected notes.");
    if (data) {
      await mkdir(join(data, "outputs"), { recursive: true });
      await writeFile(
        join(data, "outputs", a.id + "-research-notes.txt"),
        note,
        { mode: 0o600 },
      );
    }
  },
];
function schedule(a, token) {
  clearTimeout(a.timer);
  if (!a.runActive || a.lane.owner !== "agent" || token !== a.lane.epoch)
    return;
  a.timer = setTimeout(() => {
    void a.lane
      .automation(token, async () => {
        if (a.step >= steps.length) return;
        await steps[a.step](a);
        a.step++;
        a.title = await a.page.title();
        if (a.step >= steps.length) {
          a.status = "complete";
          a.runActive = false;
          a.cursor = null;
          activity(a, "Practice task complete. Notes were saved and verified.");
        } else publish(a);
      })
      .then((executed) => {
        if (executed && a.runActive && token === a.lane.epoch)
          schedule(a, token);
      })
      .catch((e) => {
        a.runActive = false;
        a.status = "error";
        a.cursor = null;
        activity(a, "Task stopped: " + e.message);
      });
  }, 1900);
}
async function handle(c) {
  if (c.action === "hello")
    return {
      practiceURL,
      engine: "Chromium",
      automation: "scripted practice task",
    };
  if (c.action === "shutdown") {
    void shutdown();
    return {};
  }
  if (c.action === "focus") {
    focused = c.agentId ? idOf(c.agentId) : null;
    return {};
  }
  if (c.action === "ensure") {
    const a = await ensure(c.agentId);
    return state(a);
  }
  const a = agents.get(idOf(c.agentId));
  if (!a?.page) throw new Error("Open this agent’s browser first.");
  if (c.action === "takeControl") {
    clearTimeout(a.timer);
    await a.lane.handoff("user");
    a.cursor = null;
    a.status = a.runActive ? "paused" : "idle";
    activity(a, "You have control. Agent browser actions are paused.");
    return state(a);
  }
  if (c.action === "returnControl") {
    await a.lane.handoff("agent");
    a.status = a.runActive
      ? "working"
      : a.hasRun && a.step >= steps.length
        ? "complete"
        : "idle";
    activity(
      a,
      a.runActive
        ? "Control returned. Continuing the practice task."
        : "Control returned to the agent.",
    );
    schedule(a, a.lane.epoch);
    return state(a);
  }
  if (c.action === "runDemo") {
    if (a.lane.owner !== "agent")
      throw new Error("Return control before starting the practice task.");
    clearTimeout(a.timer);
    const token = a.lane.invalidate();
    return a.lane.enqueue(() => {
      a.step = 0;
      a.runActive = true;
      a.hasRun = true;
      a.status = "working";
      activity(a, "Practice task started: read a source and save notes");
      schedule(a, token);
      return state(a);
    });
  }
  if (c.action === "stopDemo") {
    clearTimeout(a.timer);
    a.lane.invalidate();
    return a.lane.enqueue(() => {
      a.runActive = false;
      a.status = "idle";
      a.cursor = null;
      activity(a, "Practice task stopped");
      return state(a);
    });
  }
  if (c.action === "notes") {
    return {
      text: data
        ? await readFile(
            join(data, "outputs", a.id + "-research-notes.txt"),
            "utf8",
          ).catch(() => "")
        : "",
      path: data ? join(data, "outputs", a.id + "-research-notes.txt") : null,
    };
  }
  return a.lane.user(async () => {
    if (c.action === "navigate") {
      a.runActive = false;
      clearTimeout(a.timer);
      a.status = "loading";
      publish(a);
      try {
        await a.page.goto(validUrl(c.url), { waitUntil: "domcontentloaded" });
        a.title = await a.page.title();
        a.status = "idle";
        activity(a, "Opened " + a.page.url());
      } catch (e) {
        a.status = "error";
        activity(a, "Navigation failed: " + e.message);
        throw e;
      }
      return state(a);
    }
    if (c.action === "home") {
      await a.page.goto(practiceURL, { waitUntil: "domcontentloaded" });
      a.status = "idle";
      a.title = await a.page.title();
      activity(a, "Opened the practice page");
      return state(a);
    }
    if (c.action === "back") {
      await a.page.goBack({ waitUntil: "domcontentloaded" });
      publish(a);
      return {};
    }
    if (c.action === "forward") {
      await a.page.goForward({ waitUntil: "domcontentloaded" });
      publish(a);
      return {};
    }
    if (c.action === "reload") {
      await a.page.reload({ waitUntil: "domcontentloaded" });
      publish(a);
      return {};
    }
    if (c.action === "click") {
      if (
        !Number.isFinite(c.x) ||
        !Number.isFinite(c.y) ||
        c.x < 0 ||
        c.x > 1024 ||
        c.y < 0 ||
        c.y > 640
      )
        throw new Error("Invalid browser coordinates");
      await a.page.mouse.click(c.x, c.y, {
        button: c.button === "right" ? "right" : "left",
        clickCount: c.count === 2 ? 2 : 1,
      });
      return {};
    }
    if (c.action === "scroll") {
      await a.page.mouse.wheel(
        Math.max(-1200, Math.min(1200, Number(c.dx) || 0)),
        Math.max(-1200, Math.min(1200, Number(c.dy) || 0)),
      );
      return {};
    }
    if (c.action === "text") {
      if (typeof c.text !== "string" || c.text.length > 10000)
        throw new Error("Input is too long");
      await a.page.keyboard.insertText(c.text);
      return {};
    }
    if (c.action === "key") {
      if (typeof c.key !== "string" || c.key.length > 80)
        throw new Error("Invalid key");
      await a.page.keyboard.press(c.key);
      return {};
    }
    throw new Error("Unknown browser action");
  });
}
async function shutdown() {
  if (closing) return;
  closing = true;
  clearInterval(captureTimer);
  for (const a of agents.values()) {
    clearTimeout(a.timer);
    a.lane.invalidate();
  }
  await browser?.close().catch(() => {});
  server.close();
  process.exit(0);
}
const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
input.on("line", (line) => {
  let command;
  try {
    command = JSON.parse(line);
    if (!command || typeof command.action !== "string")
      throw new Error("Invalid command");
  } catch {
    return;
  }
  void handle(command)
    .then((result) => emit({ type: "reply", id: command.id, ok: true, result }))
    .catch((e) =>
      emit({
        type: "reply",
        id: command.id,
        ok: false,
        error: e.message || String(e),
      }),
    );
});
input.on("close", () => void shutdown());
process.on("SIGTERM", () => void shutdown());
process.on("SIGINT", () => void shutdown());
emit({ type: "ready", message: "Browser service ready" });
